
	<footer style="border-top: 4px solid #FF00FF;  ">
		<div class="container" style="padding-bottom: 50px;">
			<div class="row">
				<div class="col-md-4">
					<h3 style="color: black;"><b>TOKO SEPATU</b></h3>
					<p>Kayu Putih</p>
					<p><i class="glyphicon glyphicon-earphone"></i> +6281236051290</p>
					<p><i class="glyphicon glyphicon-envelope"></i> seprilami12@gmail.com</p>
				</div>
				<div class="col-md-4">

					<p><a href=""  style="color: #000">Menu</a></p>
			
				</div>

				<div class="col-md-4">
					
				</div>
			</div>

		</div>

		<div class="copy" style="background-color: #FF00FF; padding: 5px; color: #fff; text-align: center;">
			<span>Sepatu&copy; Sepri Lami</span>
		</div>
	</footer>

</body>
</html>