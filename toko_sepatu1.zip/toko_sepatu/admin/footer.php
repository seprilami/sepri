<footer style="background-color: gray;padding: 1px;" class="print">
	<h5 class="text-center">Copyright&copy; Ahmad Rafi Akbar Putra Hamzah</h5>
</footer>
</body>
</html>