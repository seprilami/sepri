<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solid #FF00FF"><b>Tentang Kami</b></h2>
	<p class="text-justify">Sepatu All Star. Rantai toko yang ada Indonesia terkemuka dengan Cabang-cabang  yang mengelola lebih dari 400 outlet: Jabodetabek (Gajah Mada, Pondok Pinang, Jatinegara, Cikini, Sunter, Serpong, Ciputat, Pekayon, Bogor dan Karawang), Bandung, Surabaya, Lampung, Batam, Pekanbaru, Makassar, Manado, Bali, Solo, Semarang, Balikpapan, dan Samarinda. Kami masih terus memperluas secara nasional ke kota-kota lain.</p>
<p>
Sepatu All Star adalah salah satu produk  sepatu yang bagus, Pada tahun 1908 Marquis Mills Converse mendirikan Converse Rubber Shoe Company di malden Massachusetts di Amerika Serikat. padaa  tahun 1917 Converse memperkenalkan sepatu Sneakers pertama mereka diberi nama All Star dan sepatu ini memiliki Desain Klasik, Kuliats dan Daya Tahan.</p>
</div>




 <?php 
	include 'footer.php';
 ?>